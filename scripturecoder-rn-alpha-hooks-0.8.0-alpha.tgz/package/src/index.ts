import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';

dayjs.extend(relativeTime);
dayjs.extend(utc);
dayjs.extend(timezone);

// Hooks exports
export { default as useQuery } from './hooks/use-query';
export { default as useQueryAsync } from './hooks/use-query-async';
export { default as useMutation } from './hooks/use-mutation';
export { default as useMutationAsync } from './hooks/use-mutation-async';
export { default as useDispatch } from './hooks/use-dispatch';
export { default as useSelector } from './hooks/use-selector';
export { default as useCache } from './hooks/use-cache';
export { useApp } from './store/contexts/app-context';
export { dayjs };

// Hook types
export type {
  QueryOptions,
  QueryResult,
  MutationOptions,
  MutationResponse,
  MutationResult,
  CacheOperations,
  TimingInfo,
  EncryptionOptions,
} from './hooks/types';
export type { NetworkPolicy, ConcatStrategy } from './hooks/constants';
export type {
  ParsedRoute,
  ErrorResponse,
  SuccessResponse,
  ApiResponse,
} from './hooks/utils';

// Cache types (now exported via reducers module below)

// HTTP service types and utilities
export type { HttpOptions, ContentType, HttpResponse } from './utils/service';
export { isAbortError as isHttpAbortError } from './utils/service';

// HTTP helper utilities
export {
  createAbortController,
  isAbortError,
  isCancelError,
  shouldRetry,
  formatFormData,
  formatUrlEncoded,
  safeAbort,
  createTimeoutController,
  combineAbortSignals,
} from './utils/http-helpers';

// Error handler utilities
export {
  extractErrorMessage,
  isSuccessStatus,
  isAuthError,
  createErrorResponse,
  createSuccessResponse,
} from './hooks/utils/error-handler';

// Response helpers
export { extractResponseData } from './hooks/utils/response-helpers';

// NEW: Request deduplication
export {
  getOrCreateRequest,
  cancelRequest,
  isRequestInFlight,
  getInFlightCount,
  clearAllRequests,
} from './hooks/utils/request-queue';

// NEW: Cache helpers
export {
  isCacheExpired,
  isCacheStale,
  isCacheFresh,
  getCacheData,
  createCacheEntry,
  getCacheAge,
  canUseCache,
} from './hooks/utils/cache-helpers';

// NEW: Debug logger
export {
  QueryDebugger,
  createDebugger,
  enableGlobalDebug,
  disableGlobalDebug,
  isGlobalDebugEnabled,
} from './hooks/utils/debug-logger';
export type { QueryDebugInfo } from './hooks/utils/debug-logger';

// NEW: Retry manager
export {
  retryWithBackoff,
  retryWithJitter,
} from './hooks/utils/retry-manager';
export type { RetryOptions } from './hooks/utils/retry-manager';

// NEW: Offline queue
export {
  OfflineQueue,
  getOfflineQueue,
} from './hooks/utils/offline-queue';
export type { QueuedMutation } from './hooks/utils/offline-queue';

// NEW: Refetch hooks
export {
  useRefetchOnFocus,
  useRefetchOnReconnect,
  useRefetchInterval,
} from './hooks/utils/refetch-manager';

// Configuration Provider (NEW - Recommended)
export { AlphaProvider } from './store/contexts/alpha-provider';
export type { AlphaConfig } from './config';
export { DEFAULT_CONFIG } from './config';
export { useAlphaConfig } from './store/contexts/config-context';

// Store exports
export { default as AppProvider } from './store/contexts/app-context';
export { AppContextValue } from './store/contexts/app-context';
export { store, createAlphaStore, defaultStore } from './store';
export type {
  AppDispatch,
  RootState,
  CustomReducers,
  StoreOptions,
} from './store';

// Reducer exports - All reducers, actions, and types
export {
  appReducer,
  appActions,
  cacheReducer,
  cacheActions,
  threadReducer,
  threadActions,
  setMaxCacheSize,
  getCacheMetadata,
} from './store/reducers';
export type {
  CoreAppState,
  CacheEntry,
  CacheState,
  CacheMetadata,
} from './store/reducers';

// TypeScript helpers for custom stores
export {
  createTypedSelector,
  createTypedDispatch,
  useAppSelector,
  useAppDispatch,
  createSelector,
  createSlice,
} from './store/type-helpers';
export type {
  InferActions,
  ExtendedRootState,
  ExtendedAppContext,
  StateFromReducer,
} from './store/type-helpers';

export { config as alphaConfig, naira } from './config';
export { default as PATHS } from './paths';
export * from './types';

// HTTP Config (Advanced use)
export { setHttpConfig, getHttpConfig } from './utils/service';

export { default as formatMoney } from './utils/money';
export {
  encrypt,
  decrypt,
  setEncryptionConfig,
  getEncryptionConfig,
  isValidEncryptionConfig,
  generateEncryptionConfig,
} from './utils/crypto';
export type { EncryptionConfig } from './utils/crypto';
export { default as storage } from './utils/storage';

// Additional utility functions
export { default as getMime } from './utils/getMime';
export { default as capitalize } from './utils/capitalize';
export { default as Toast } from './utils/toast';
export { default as readFile } from './utils/readFile';

// NEW: Logger utility
export { logger } from './utils/logger';

// HTTP service (advanced use - direct access to http function)
export { default as http } from './utils/service';
export type { Method } from './utils/service';

// NEW: Constants
export {
  DEFAULT_CACHE_TTL,
  DEFAULT_STALE_TIME,
  MAX_CACHE_SIZE,
  NETWORK_TIMEOUT,
  ERROR_MESSAGES,
  STATUS_CODES,
} from './hooks/constants';
